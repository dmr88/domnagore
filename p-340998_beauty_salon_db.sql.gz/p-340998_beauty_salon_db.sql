-- Adminer 4.8.1 MySQL 5.5.5-10.4.34-MariaDB-1:10.4.34+maria~ubu2004 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `registrations`;
CREATE TABLE `registrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `regName` varchar(255) NOT NULL,
  `person_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `registrations` (`id`, `uid`, `time`, `regName`, `person_id`, `service_id`) VALUES
(1,	1,	'2024-03-20 13:30:00',	'Ламинирование ресниц',	0,	0),
(2,	1,	'2024-03-20 14:00:00',	'Маникюр',	0,	0),
(3,	2,	'2024-03-20 12:00:00',	'Маникюр',	0,	0),
(4,	2,	'2024-03-19 19:17:00',	'Наращивание ресниц',	0,	0),
(5,	2,	'2024-03-31 19:17:00',	'Наращивание ресниц',	0,	0),
(6,	3,	'2024-03-19 22:30:00',	'Окрашивание',	0,	0),
(7,	4,	'2024-03-22 01:00:00',	'Маникюр',	0,	0),
(8,	5,	'2024-03-21 21:18:00',	'Педикюр',	0,	0),
(9,	5,	'2024-03-20 21:30:00',	'Ламинирование ресниц',	0,	0),
(10,	5,	'2024-03-20 21:30:00',	'Ламинирование ресниц',	0,	0),
(11,	2,	'2024-03-05 22:15:00',	'Окрашивание',	0,	0),
(12,	2,	'1113-12-11 11:20:00',	'Маникюр',	0,	0),
(13,	6,	'1111-11-11 11:11:00',	'Педикюр',	0,	0),
(14,	1,	'2024-03-20 16:50:00',	'Ламинирование ресниц',	0,	0),
(15,	5,	'2024-03-22 19:07:00',	'Наращивание ресниц',	0,	0),
(16,	7,	'2024-03-27 13:47:00',	'Ламинирование ресниц',	0,	0),
(17,	8,	'2024-03-28 15:55:00',	'Маникюр',	0,	0),
(18,	8,	'2024-03-28 15:55:00',	'Маникюр',	0,	0),
(19,	8,	'2024-03-28 15:55:00',	'Маникюр',	0,	0),
(20,	9,	'2024-03-30 11:25:00',	'Педикюр',	0,	0),
(21,	10,	'2024-05-15 12:00:00',	'Наращивание ресниц',	0,	0),
(22,	11,	'2024-05-10 10:00:00',	'Ламинирование ресниц',	0,	0),
(23,	12,	'2024-05-16 10:00:00',	'Маникюр',	0,	0),
(24,	1,	'2024-05-30 12:00:00',	'Окрашивание',	3,	0),
(25,	1,	'2024-05-18 13:00:00',	'Наращивание ресниц',	4,	0),
(26,	7,	'2024-06-10 10:00:00',	'Маникюр',	4,	0),
(27,	14,	'2024-05-17 12:00:00',	'Маникюр',	3,	0),
(28,	1,	'2024-05-29 16:09:00',	'Наращивание ресниц',	8,	0);

DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `price` int(11) NOT NULL,
  `desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `service` (`id`, `name`, `price`, `desc`) VALUES
(1,	'Ламинирование ресниц',	5000,	'Ламинирование ресниц — это процедура, направленная на укрепление и визуальное увеличение объема естественных ресниц.'),
(2,	'Наращивание ресниц',	6000,	'Наращивание ресниц — это процесс добавления искусственных ресниц к естественным для увеличения их объема и длины.'),
(3,	'Маникюр',	5000,	'Маникюр — это уход за ногтями и кожей рук, включающий обрезание, формирование и покрытие ногтевой пластины.'),
(4,	'Педикюр',	6000,	'Педикюр — это процедура ухода за ногтями и кожей стоп, включая обрезание ногтей, удаление ороговевшей кожи и массаж стоп.'),
(5,	'Окрашивание',	20000,	'Окрашивание — это процедура изменения цвета волос с помощью красящих средств.'),
(6,	'Стрижка',	25000,	'Стрижка — это процесс обрезания или формирования волос с целью изменения их длины или стиля.');

DROP TABLE IF EXISTS `service_person`;
CREATE TABLE `service_person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `service_person` (`id`, `user_id`, `service_id`) VALUES
(1,	3,	1),
(2,	4,	2),
(3,	8,	3),
(4,	3,	4),
(5,	8,	5),
(6,	4,	6);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `role_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `users` (`id`, `username`, `email`, `phone`, `password`, `isAdmin`, `role_id`) VALUES
(1,	'admin',	'admin@mail.com',	'',	'21232f297a57a5a743894a0e4a801fc3',	1,	0),
(3,	'Елена Борисовна',	'aa@aa.a',	'77075643434',	'4124bc0a9335c27f086f24ba207a4912',	0,	3),
(4,	'Василиса Прекрасная',	'shjsjagwga@gmail.com',	'88005553535',	'827ccb0eea8a706c4c34a16891f84e7b',	0,	3),
(7,	'Ram',	'121112@gmail.com',	'9888877',	'92f0e3015db06807a532591d30840f04',	0,	0),
(8,	'Света Светлая',	'sveta-sun@mail.ru',	'777656453',	'418b562861fefeeb06131161c078ac78',	0,	3),
(9,	'aiken',	'aiken@gmail.com',	'112',	'202cb962ac59075b964b07152d234b70',	0,	0),
(10,	'aiken',	'kumarov777aiken@gmail.com',	'+77471149480',	'a24d4e513ff5d5ff329896c3156db5d3',	0,	0),
(11,	'Marzhan',	'marzanotegenova@gmail.com',	'+77058459413',	'0fee6c9e8b6723f18f7d63846c0bdedb',	0,	0),
(12,	'chingis',	'kumarov777aiken@gmail.com',	'77472479842',	'd8578edf8458ce06fbc5bb76a58c5ca4',	0,	0),
(13,	'Marzhan',	'kumarov777aiken@gmail.com',	'77471149480',	'a24d4e513ff5d5ff329896c3156db5d3',	0,	0),
(14,	'aiken',	'kumarov777aiken@gmail.com',	'7471149480',	'a24d4e513ff5d5ff329896c3156db5d3',	0,	0);

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `user_roles` (`id`, `name`) VALUES
(1,	'user'),
(2,	'admin'),
(3,	'manager');

-- 2024-05-26 05:57:16
